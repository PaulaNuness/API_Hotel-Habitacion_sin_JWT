package com.example.Tarea_obligatoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TareaObligatoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
